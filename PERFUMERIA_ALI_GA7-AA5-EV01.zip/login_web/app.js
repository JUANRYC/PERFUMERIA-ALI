//Declaro variables de entorno
const express 	= require("express");
const path 		= require("path");
const bodyParser= require("body-parser");
const app 		= express();

const bcrypt 	= require("bcrypt"); 		//Modulo para encriptación de password
const mongoose 	= require("mongoose");
const User 		= require("./public/user.js");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(path.join(__dirname, "public"))); //Cargar contenido estatico

//Configuramos la base de datos
const mongo_url = ("mongodb://127.0.0.1:27017/perfumeriadb");

//Validamos la conexion
mongoose.connect(mongo_url, function(err) {
	if (err) {
		throw err;
	} else {
	  console.log(`Conectado exitosamente a ${mongo_url}`);
	}
});

//Registrando usuarios nuevos
app.post("/Registrarse", (req, res) => {
	const { nomuser, password } = req.body;

	const user = new User({nomuser, password});
	user.save(err => {
		if(err){
		 res.status(500).send("ERROR AL REGISTRAR AL USUARIO");
		} else{
		 res.status(200).send("USUARIO REGISTRADO CON ÉXITO");
		}
	});
});

//Validando usuarios ya registrados
app.post("/Autenticacion", (req, res) => {
	const { nomuser, password } = req.body;

	User.findOne({nomuser}, (err, user) => {
		if(err){
			res.status(500).send("ERROR AL AUTENTICAR AL USUARIO");
		} else if(!user){
			res.status(500).send("EL USUARIO NO EXISTE");
		} else{
			user.isCorrectPassword(password, (err, result) =>{
				if(err){
					res.status(500).send("ERROR AL AUTENTICAR");
				} else if(result){
					res.status(200).send("USUARIO AUTENTICADO CORRECTAMENTE");
				} else{
					res.status(500).send("USUARIO Y/O CONTRASEÑA INCORRECTOS");
				}
			});
		}
	});
});

app.listen(4000, () => {
	console.log(">>> Servidor iniciado con éxito <<<");
})
module.exports = app;