const mongoose 	= require("mongoose");
const bcrypt 	= require("bcrypt"); 		//Modulo para encriptación de password


const saltRounds = 10;//Las veces que puede encriptar el algorigtmo

//Definimos el Esquema
const UserSchema = new mongoose.Schema({
    nomuser: { type: String, required: true, unique:true }, //Campos para la colección
    password: { type: String, required: true }
   });

//Definimos una función antes de ingresar a la BD [Hacer validacion]
UserSchema.pre("save", function(next){
	if(this.isNew || this.isModified("password")){
		
		const document = this;
		
		bcrypt.hash(document.password, saltRounds, (err, hashedPassword) => {
			if(err){
				next(err); //continua el flujo de la funcion
			} else{
				document.password = hashedPassword;
				next();
			}
		});
	} else {
		next();
	}
});

//Definimos otra funcion para comparar el usuario cuando se loguee
UserSchema.methods.isCorrectPassword = function(password, callback){
	bcrypt.compare(password, this.password, function(err, same){
		if(err){
			callback(err);
		} else {
			callback(err, same);
		}
	});
}

//Exportamos el modelo
module.exports = mongoose.model("user", UserSchema);